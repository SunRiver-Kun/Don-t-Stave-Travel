﻿namespace DST
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TextBox textBox2;
            System.Windows.Forms.TextBox textBox1;
            System.Windows.Forms.TextBox textBox3;
            System.Windows.Forms.TextBox TB_time0;
            System.Windows.Forms.TextBox textBox5;
            System.Windows.Forms.TextBox textBox4;
            System.Windows.Forms.TextBox textBox7;
            System.Windows.Forms.TextBox textBox9;
            System.Windows.Forms.TextBox textBox11;
            System.Windows.Forms.TextBox textBox8;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.bakcepackName = new System.Windows.Forms.TextBox();
            this.TB_Dialogue = new System.Windows.Forms.TextBox();
            this.buttonGroup = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupMake = new System.Windows.Forms.GroupBox();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.工具 = new System.Windows.Forms.ToolStripMenuItem();
            this.照明 = new System.Windows.Forms.ToolStripMenuItem();
            this.食物 = new System.Windows.Forms.ToolStripMenuItem();
            this.烹饪 = new System.Windows.Forms.ToolStripMenuItem();
            this.菜肴 = new System.Windows.Forms.ToolStripMenuItem();
            this.生存 = new System.Windows.Forms.ToolStripMenuItem();
            this.战斗 = new System.Windows.Forms.ToolStripMenuItem();
            this.服装 = new System.Windows.Forms.ToolStripMenuItem();
            this.makeButton = new System.Windows.Forms.Button();
            this.discardButton = new System.Windows.Forms.Button();
            this.backpackList = new System.Windows.Forms.CheckedListBox();
            this.basedata = new System.Windows.Forms.GroupBox();
            this.TB_hunger = new System.Windows.Forms.TextBox();
            this.TB_sanity = new System.Windows.Forms.TextBox();
            this.TB_health = new System.Windows.Forms.TextBox();
            this.timer_Dialogue = new System.Windows.Forms.Timer(this.components);
            this.timer_baseupdata = new System.Windows.Forms.Timer(this.components);
            this.timer_Time = new System.Windows.Forms.Timer(this.components);
            this.waw = new System.Windows.Forms.GroupBox();
            this.TB_creature = new System.Windows.Forms.TextBox();
            this.TB_hat = new System.Windows.Forms.TextBox();
            this.TB_armor = new System.Windows.Forms.TextBox();
            this.TB_weapon = new System.Windows.Forms.TextBox();
            this.TB_input = new System.Windows.Forms.TextBox();
            this.TB_time = new System.Windows.Forms.TextBox();
            this.TB_address = new System.Windows.Forms.TextBox();
            this.MainPicture = new System.Windows.Forms.PictureBox();
            textBox2 = new System.Windows.Forms.TextBox();
            textBox1 = new System.Windows.Forms.TextBox();
            textBox3 = new System.Windows.Forms.TextBox();
            TB_time0 = new System.Windows.Forms.TextBox();
            textBox5 = new System.Windows.Forms.TextBox();
            textBox4 = new System.Windows.Forms.TextBox();
            textBox7 = new System.Windows.Forms.TextBox();
            textBox9 = new System.Windows.Forms.TextBox();
            textBox11 = new System.Windows.Forms.TextBox();
            textBox8 = new System.Windows.Forms.TextBox();
            this.buttonGroup.SuspendLayout();
            this.groupMake.SuspendLayout();
            this.menuStrip.SuspendLayout();
            this.basedata.SuspendLayout();
            this.waw.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MainPicture)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox2
            // 
            textBox2.BackColor = System.Drawing.Color.OrangeRed;
            textBox2.Font = new System.Drawing.Font("宋体", 12.22642F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            textBox2.Location = new System.Drawing.Point(10, 24);
            textBox2.Name = "textBox2";
            textBox2.ReadOnly = true;
            textBox2.Size = new System.Drawing.Size(114, 28);
            textBox2.TabIndex = 1;
            textBox2.Text = "血量";
            // 
            // textBox1
            // 
            textBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            textBox1.Font = new System.Drawing.Font("宋体", 12.22642F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            textBox1.Location = new System.Drawing.Point(10, 58);
            textBox1.Name = "textBox1";
            textBox1.ReadOnly = true;
            textBox1.Size = new System.Drawing.Size(114, 28);
            textBox1.TabIndex = 2;
            textBox1.Text = "精神";
            // 
            // textBox3
            // 
            textBox3.BackColor = System.Drawing.Color.Bisque;
            textBox3.Font = new System.Drawing.Font("宋体", 12.22642F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            textBox3.Location = new System.Drawing.Point(10, 92);
            textBox3.Name = "textBox3";
            textBox3.ReadOnly = true;
            textBox3.Size = new System.Drawing.Size(114, 28);
            textBox3.TabIndex = 3;
            textBox3.Text = "饥饿";
            // 
            // TB_time0
            // 
            TB_time0.Font = new System.Drawing.Font("宋体", 12.22642F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            TB_time0.Location = new System.Drawing.Point(2, 39);
            TB_time0.Margin = new System.Windows.Forms.Padding(0);
            TB_time0.Name = "TB_time0";
            TB_time0.ReadOnly = true;
            TB_time0.Size = new System.Drawing.Size(44, 28);
            TB_time0.TabIndex = 0;
            TB_time0.Text = "时间";
            // 
            // textBox5
            // 
            textBox5.Font = new System.Drawing.Font("宋体", 12.22642F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            textBox5.Location = new System.Drawing.Point(209, 39);
            textBox5.Margin = new System.Windows.Forms.Padding(0);
            textBox5.Name = "textBox5";
            textBox5.ReadOnly = true;
            textBox5.Size = new System.Drawing.Size(44, 28);
            textBox5.TabIndex = 3;
            textBox5.Text = "地点";
            // 
            // textBox4
            // 
            textBox4.Font = new System.Drawing.Font("宋体", 12.22642F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            textBox4.Location = new System.Drawing.Point(449, 39);
            textBox4.Margin = new System.Windows.Forms.Padding(0);
            textBox4.Name = "textBox4";
            textBox4.ReadOnly = true;
            textBox4.Size = new System.Drawing.Size(62, 28);
            textBox4.TabIndex = 5;
            textBox4.Text = "控制台";
            // 
            // textBox7
            // 
            textBox7.Font = new System.Drawing.Font("宋体", 12.22642F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            textBox7.Location = new System.Drawing.Point(2, 11);
            textBox7.Margin = new System.Windows.Forms.Padding(0);
            textBox7.Name = "textBox7";
            textBox7.ReadOnly = true;
            textBox7.Size = new System.Drawing.Size(44, 28);
            textBox7.TabIndex = 6;
            textBox7.Text = "武器";
            // 
            // textBox9
            // 
            textBox9.Font = new System.Drawing.Font("宋体", 12.22642F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            textBox9.Location = new System.Drawing.Point(209, 11);
            textBox9.Margin = new System.Windows.Forms.Padding(0);
            textBox9.Name = "textBox9";
            textBox9.ReadOnly = true;
            textBox9.Size = new System.Drawing.Size(77, 28);
            textBox9.TabIndex = 8;
            textBox9.Text = "防具";
            // 
            // textBox11
            // 
            textBox11.Font = new System.Drawing.Font("宋体", 12.22642F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            textBox11.Location = new System.Drawing.Point(449, 11);
            textBox11.Margin = new System.Windows.Forms.Padding(0);
            textBox11.Name = "textBox11";
            textBox11.ReadOnly = true;
            textBox11.Size = new System.Drawing.Size(77, 28);
            textBox11.TabIndex = 10;
            textBox11.Text = "帽子";
            // 
            // textBox8
            // 
            textBox8.Font = new System.Drawing.Font("宋体", 12.22642F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            textBox8.Location = new System.Drawing.Point(654, 11);
            textBox8.Margin = new System.Windows.Forms.Padding(0);
            textBox8.Name = "textBox8";
            textBox8.ReadOnly = true;
            textBox8.Size = new System.Drawing.Size(80, 28);
            textBox8.TabIndex = 12;
            textBox8.Text = "名字";
            // 
            // bakcepackName
            // 
            this.bakcepackName.CausesValidation = false;
            this.bakcepackName.Font = new System.Drawing.Font("宋体", 14.9434F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bakcepackName.Location = new System.Drawing.Point(903, 14);
            this.bakcepackName.Name = "bakcepackName";
            this.bakcepackName.ReadOnly = true;
            this.bakcepackName.Size = new System.Drawing.Size(169, 33);
            this.bakcepackName.TabIndex = 3;
            this.bakcepackName.TabStop = false;
            this.bakcepackName.Text = "小背包";
            this.bakcepackName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_Dialogue
            // 
            this.TB_Dialogue.Font = new System.Drawing.Font("华文行楷", 16.30189F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TB_Dialogue.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.TB_Dialogue.Location = new System.Drawing.Point(2, 4);
            this.TB_Dialogue.Multiline = true;
            this.TB_Dialogue.Name = "TB_Dialogue";
            this.TB_Dialogue.ReadOnly = true;
            this.TB_Dialogue.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TB_Dialogue.Size = new System.Drawing.Size(869, 445);
            this.TB_Dialogue.TabIndex = 0;
            // 
            // buttonGroup
            // 
            this.buttonGroup.Controls.Add(this.button4);
            this.buttonGroup.Controls.Add(this.button3);
            this.buttonGroup.Controls.Add(this.button2);
            this.buttonGroup.Controls.Add(this.button1);
            this.buttonGroup.Location = new System.Drawing.Point(2, 541);
            this.buttonGroup.Name = "buttonGroup";
            this.buttonGroup.Size = new System.Drawing.Size(869, 127);
            this.buttonGroup.TabIndex = 1;
            this.buttonGroup.TabStop = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button4.Font = new System.Drawing.Font("华文仿宋", 12.22641F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button4.Location = new System.Drawing.Point(51, 30);
            this.button4.Margin = new System.Windows.Forms.Padding(50);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(160, 76);
            this.button4.TabIndex = 3;
            this.button4.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.Font = new System.Drawing.Font("华文仿宋", 12.22641F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button3.Location = new System.Drawing.Point(252, 30);
            this.button3.Margin = new System.Windows.Forms.Padding(50);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(160, 76);
            this.button3.TabIndex = 2;
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Font = new System.Drawing.Font("华文仿宋", 12.22641F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button2.Location = new System.Drawing.Point(453, 30);
            this.button2.Margin = new System.Windows.Forms.Padding(50);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(160, 76);
            this.button2.TabIndex = 1;
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Font = new System.Drawing.Font("华文仿宋", 12.22641F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(654, 30);
            this.button1.Margin = new System.Windows.Forms.Padding(50);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(160, 76);
            this.button1.TabIndex = 0;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // groupMake
            // 
            this.groupMake.Controls.Add(this.menuStrip);
            this.groupMake.Location = new System.Drawing.Point(7, 9);
            this.groupMake.Name = "groupMake";
            this.groupMake.Size = new System.Drawing.Size(841, 362);
            this.groupMake.TabIndex = 6;
            this.groupMake.TabStop = false;
            this.groupMake.Visible = false;
            // 
            // menuStrip
            // 
            this.menuStrip.Font = new System.Drawing.Font("楷体", 14.9434F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.menuStrip.ImageScalingSize = new System.Drawing.Size(18, 18);
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.工具,
            this.照明,
            this.食物,
            this.生存,
            this.战斗,
            this.服装});
            this.menuStrip.Location = new System.Drawing.Point(3, 18);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.ShowItemToolTips = true;
            this.menuStrip.Size = new System.Drawing.Size(835, 31);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "menuStrip1";
            // 
            // 工具
            // 
            this.工具.Image = global::DST.Properties.Resources.tool;
            this.工具.Margin = new System.Windows.Forms.Padding(45, 0, 0, 0);
            this.工具.Name = "工具";
            this.工具.Size = new System.Drawing.Size(88, 27);
            this.工具.Text = "工具";
            // 
            // 照明
            // 
            this.照明.Image = global::DST.Properties.Resources.light;
            this.照明.Margin = new System.Windows.Forms.Padding(45, 0, 0, 0);
            this.照明.Name = "照明";
            this.照明.Size = new System.Drawing.Size(88, 27);
            this.照明.Text = "照明";
            // 
            // 食物
            // 
            this.食物.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.烹饪,
            this.菜肴});
            this.食物.Image = global::DST.Properties.Resources.food;
            this.食物.Margin = new System.Windows.Forms.Padding(45, 0, 0, 0);
            this.食物.Name = "食物";
            this.食物.Size = new System.Drawing.Size(88, 27);
            this.食物.Text = "食物";
            // 
            // 烹饪
            // 
            this.烹饪.Enabled = false;
            this.烹饪.Name = "烹饪";
            this.烹饪.Size = new System.Drawing.Size(130, 28);
            this.烹饪.Text = "烹饪";
            this.烹饪.ToolTipText = "简单的烹饪食物";
            // 
            // 菜肴
            // 
            this.菜肴.Enabled = false;
            this.菜肴.Name = "菜肴";
            this.菜肴.Size = new System.Drawing.Size(130, 28);
            this.菜肴.Text = "菜肴";
            this.菜肴.ToolTipText = "制作美味佳肴";
            // 
            // 生存
            // 
            this.生存.Image = global::DST.Properties.Resources.live;
            this.生存.Margin = new System.Windows.Forms.Padding(45, 0, 0, 0);
            this.生存.Name = "生存";
            this.生存.Size = new System.Drawing.Size(88, 27);
            this.生存.Text = "生存";
            // 
            // 战斗
            // 
            this.战斗.Image = global::DST.Properties.Resources.fight;
            this.战斗.Margin = new System.Windows.Forms.Padding(45, 0, 0, 0);
            this.战斗.Name = "战斗";
            this.战斗.Size = new System.Drawing.Size(88, 27);
            this.战斗.Text = "战斗";
            // 
            // 服装
            // 
            this.服装.Image = global::DST.Properties.Resources.clothes;
            this.服装.Margin = new System.Windows.Forms.Padding(45, 0, 0, 0);
            this.服装.Name = "服装";
            this.服装.Size = new System.Drawing.Size(88, 27);
            this.服装.Text = "服装";
            // 
            // makeButton
            // 
            this.makeButton.BackColor = System.Drawing.Color.Transparent;
            this.makeButton.Location = new System.Drawing.Point(914, 499);
            this.makeButton.Name = "makeButton";
            this.makeButton.Size = new System.Drawing.Size(74, 44);
            this.makeButton.TabIndex = 7;
            this.makeButton.Text = "制作";
            this.makeButton.UseVisualStyleBackColor = false;
            this.makeButton.Click += new System.EventHandler(this.makeButton_Click);
            // 
            // discardButton
            // 
            this.discardButton.BackColor = System.Drawing.Color.Transparent;
            this.discardButton.Location = new System.Drawing.Point(995, 499);
            this.discardButton.Name = "discardButton";
            this.discardButton.Size = new System.Drawing.Size(74, 44);
            this.discardButton.TabIndex = 8;
            this.discardButton.Text = "丢弃";
            this.discardButton.UseVisualStyleBackColor = false;
            this.discardButton.Click += new System.EventHandler(this.discardButton_Click);
            // 
            // backpackList
            // 
            this.backpackList.CheckOnClick = true;
            this.backpackList.Font = new System.Drawing.Font("楷体", 14.9434F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.backpackList.HorizontalScrollbar = true;
            this.backpackList.IntegralHeight = false;
            this.backpackList.Items.AddRange(new object[] {
            "夏湾制作",
            "献给饥荒"});
            this.backpackList.Location = new System.Drawing.Point(904, 56);
            this.backpackList.Name = "backpackList";
            this.backpackList.Size = new System.Drawing.Size(167, 424);
            this.backpackList.TabIndex = 9;
            // 
            // basedata
            // 
            this.basedata.BackColor = System.Drawing.Color.Transparent;
            this.basedata.Controls.Add(this.TB_hunger);
            this.basedata.Controls.Add(this.TB_sanity);
            this.basedata.Controls.Add(this.TB_health);
            this.basedata.Controls.Add(textBox3);
            this.basedata.Controls.Add(textBox1);
            this.basedata.Controls.Add(textBox2);
            this.basedata.Location = new System.Drawing.Point(913, 541);
            this.basedata.Name = "basedata";
            this.basedata.Size = new System.Drawing.Size(158, 126);
            this.basedata.TabIndex = 10;
            this.basedata.TabStop = false;
            // 
            // TB_hunger
            // 
            this.TB_hunger.BackColor = System.Drawing.Color.Bisque;
            this.TB_hunger.Font = new System.Drawing.Font("宋体", 12.22642F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TB_hunger.Location = new System.Drawing.Point(51, 92);
            this.TB_hunger.Name = "TB_hunger";
            this.TB_hunger.ReadOnly = true;
            this.TB_hunger.Size = new System.Drawing.Size(101, 28);
            this.TB_hunger.TabIndex = 6;
            this.TB_hunger.Text = "100";
            this.TB_hunger.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_sanity
            // 
            this.TB_sanity.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.TB_sanity.Font = new System.Drawing.Font("宋体", 12.22642F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TB_sanity.Location = new System.Drawing.Point(51, 58);
            this.TB_sanity.Name = "TB_sanity";
            this.TB_sanity.ReadOnly = true;
            this.TB_sanity.Size = new System.Drawing.Size(101, 28);
            this.TB_sanity.TabIndex = 5;
            this.TB_sanity.Text = "100";
            this.TB_sanity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_health
            // 
            this.TB_health.BackColor = System.Drawing.Color.OrangeRed;
            this.TB_health.Font = new System.Drawing.Font("宋体", 12.22642F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TB_health.Location = new System.Drawing.Point(51, 24);
            this.TB_health.Name = "TB_health";
            this.TB_health.ReadOnly = true;
            this.TB_health.Size = new System.Drawing.Size(101, 28);
            this.TB_health.TabIndex = 4;
            this.TB_health.Text = "100";
            this.TB_health.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timer_Dialogue
            // 
            this.timer_Dialogue.Interval = 1000;
            this.timer_Dialogue.Tick += new System.EventHandler(this.Print);
            // 
            // timer_baseupdata
            // 
            this.timer_baseupdata.Enabled = true;
            this.timer_baseupdata.Interval = 6000;
            // 
            // timer_Time
            // 
            this.timer_Time.Enabled = true;
            this.timer_Time.Interval = 3000;
            this.timer_Time.Tick += new System.EventHandler(this.ReflashTime);
            // 
            // waw
            // 
            this.waw.Controls.Add(this.TB_creature);
            this.waw.Controls.Add(textBox8);
            this.waw.Controls.Add(this.TB_hat);
            this.waw.Controls.Add(textBox11);
            this.waw.Controls.Add(this.TB_armor);
            this.waw.Controls.Add(textBox9);
            this.waw.Controls.Add(this.TB_weapon);
            this.waw.Controls.Add(textBox7);
            this.waw.Controls.Add(textBox4);
            this.waw.Controls.Add(this.TB_input);
            this.waw.Controls.Add(textBox5);
            this.waw.Controls.Add(this.TB_time);
            this.waw.Controls.Add(this.TB_address);
            this.waw.Controls.Add(TB_time0);
            this.waw.Location = new System.Drawing.Point(7, 463);
            this.waw.Name = "waw";
            this.waw.Size = new System.Drawing.Size(866, 72);
            this.waw.TabIndex = 11;
            this.waw.TabStop = false;
            // 
            // TB_creature
            // 
            this.TB_creature.Font = new System.Drawing.Font("宋体", 12.22642F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TB_creature.Location = new System.Drawing.Point(698, 11);
            this.TB_creature.Margin = new System.Windows.Forms.Padding(0);
            this.TB_creature.Name = "TB_creature";
            this.TB_creature.ReadOnly = true;
            this.TB_creature.Size = new System.Drawing.Size(164, 28);
            this.TB_creature.TabIndex = 13;
            this.TB_creature.Text = "旅行者";
            this.TB_creature.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TB_creature.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TB_creature_KeyDown);
            // 
            // TB_hat
            // 
            this.TB_hat.Font = new System.Drawing.Font("宋体", 12.22642F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TB_hat.Location = new System.Drawing.Point(493, 11);
            this.TB_hat.Margin = new System.Windows.Forms.Padding(0);
            this.TB_hat.Name = "TB_hat";
            this.TB_hat.ReadOnly = true;
            this.TB_hat.Size = new System.Drawing.Size(157, 28);
            this.TB_hat.TabIndex = 11;
            this.TB_hat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_armor
            // 
            this.TB_armor.Font = new System.Drawing.Font("宋体", 12.22642F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TB_armor.Location = new System.Drawing.Point(253, 11);
            this.TB_armor.Margin = new System.Windows.Forms.Padding(0);
            this.TB_armor.Name = "TB_armor";
            this.TB_armor.ReadOnly = true;
            this.TB_armor.Size = new System.Drawing.Size(187, 28);
            this.TB_armor.TabIndex = 9;
            this.TB_armor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_weapon
            // 
            this.TB_weapon.Font = new System.Drawing.Font("宋体", 12.22642F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TB_weapon.Location = new System.Drawing.Point(46, 11);
            this.TB_weapon.Margin = new System.Windows.Forms.Padding(0);
            this.TB_weapon.Name = "TB_weapon";
            this.TB_weapon.ReadOnly = true;
            this.TB_weapon.Size = new System.Drawing.Size(154, 28);
            this.TB_weapon.TabIndex = 7;
            this.TB_weapon.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_input
            // 
            this.TB_input.Font = new System.Drawing.Font("宋体", 12.22642F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TB_input.Location = new System.Drawing.Point(511, 39);
            this.TB_input.Margin = new System.Windows.Forms.Padding(0);
            this.TB_input.Name = "TB_input";
            this.TB_input.Size = new System.Drawing.Size(351, 28);
            this.TB_input.TabIndex = 4;
            this.TB_input.Tag = "";
            this.TB_input.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TB_input.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TB_input_KeyDown);
            // 
            // TB_time
            // 
            this.TB_time.Font = new System.Drawing.Font("宋体", 12.22642F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TB_time.Location = new System.Drawing.Point(46, 39);
            this.TB_time.Margin = new System.Windows.Forms.Padding(0);
            this.TB_time.Name = "TB_time";
            this.TB_time.ReadOnly = true;
            this.TB_time.Size = new System.Drawing.Size(154, 28);
            this.TB_time.TabIndex = 2;
            this.TB_time.Text = "6:00:00 早上";
            this.TB_time.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TB_address
            // 
            this.TB_address.Font = new System.Drawing.Font("宋体", 12.22642F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TB_address.Location = new System.Drawing.Point(253, 39);
            this.TB_address.Margin = new System.Windows.Forms.Padding(0);
            this.TB_address.Name = "TB_address";
            this.TB_address.ReadOnly = true;
            this.TB_address.Size = new System.Drawing.Size(187, 28);
            this.TB_address.TabIndex = 1;
            this.TB_address.Text = "东北大学";
            this.TB_address.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // MainPicture
            // 
            this.MainPicture.BackColor = System.Drawing.Color.White;
            this.MainPicture.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.MainPicture.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MainPicture.Enabled = false;
            this.MainPicture.Image = ((System.Drawing.Image)(resources.GetObject("MainPicture.Image")));
            this.MainPicture.Location = new System.Drawing.Point(2, 4);
            this.MainPicture.Name = "MainPicture";
            this.MainPicture.Size = new System.Drawing.Size(846, 445);
            this.MainPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.MainPicture.TabIndex = 5;
            this.MainPicture.TabStop = false;
            this.MainPicture.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1081, 680);
            this.Controls.Add(this.waw);
            this.Controls.Add(this.basedata);
            this.Controls.Add(this.backpackList);
            this.Controls.Add(this.discardButton);
            this.Controls.Add(this.makeButton);
            this.Controls.Add(this.bakcepackName);
            this.Controls.Add(this.buttonGroup);
            this.Controls.Add(this.groupMake);
            this.Controls.Add(this.TB_Dialogue);
            this.Controls.Add(this.MainPicture);
            this.MainMenuStrip = this.menuStrip;
            this.Name = "Form1";
            this.Text = "Don\'t Stave Traveler";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.buttonGroup.ResumeLayout(false);
            this.groupMake.ResumeLayout(false);
            this.groupMake.PerformLayout();
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.basedata.ResumeLayout(false);
            this.basedata.PerformLayout();
            this.waw.ResumeLayout(false);
            this.waw.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MainPicture)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupMake;
        private System.Windows.Forms.ToolStripMenuItem 工具;
        private System.Windows.Forms.ToolStripMenuItem 照明;
        private System.Windows.Forms.ToolStripMenuItem 生存;
        private System.Windows.Forms.ToolStripMenuItem 战斗;
        private System.Windows.Forms.ToolStripMenuItem 服装;
        private System.Windows.Forms.TextBox TB_hunger;
        private System.Windows.Forms.TextBox TB_sanity;
        private System.Windows.Forms.TextBox TB_health;
        public System.Windows.Forms.TextBox TB_Dialogue;
        public System.Windows.Forms.CheckedListBox backpackList;
        public System.Windows.Forms.GroupBox basedata;
        private System.Windows.Forms.GroupBox waw;
        public System.Windows.Forms.GroupBox buttonGroup;
        public System.Windows.Forms.MenuStrip menuStrip;
        public System.Windows.Forms.Button makeButton;
        public System.Windows.Forms.Button discardButton;
        public System.Windows.Forms.Timer timer_Dialogue;
        public System.Windows.Forms.Timer timer_baseupdata;
        public System.Windows.Forms.Timer timer_Time;
        public System.Windows.Forms.TextBox TB_address;
        public System.Windows.Forms.TextBox TB_time;
        public System.Windows.Forms.TextBox TB_input;
        public System.Windows.Forms.ToolStripMenuItem 食物;
        public System.Windows.Forms.TextBox TB_hat;
        public System.Windows.Forms.TextBox TB_armor;
        public System.Windows.Forms.TextBox TB_weapon;
        public System.Windows.Forms.TextBox TB_creature;
        public System.Windows.Forms.PictureBox MainPicture;
        public System.Windows.Forms.Button button3;
        public System.Windows.Forms.Button button2;
        public System.Windows.Forms.Button button1;
        public System.Windows.Forms.Button button4;
        public System.Windows.Forms.TextBox bakcepackName;
        public System.Windows.Forms.ToolStripMenuItem 烹饪;
        public System.Windows.Forms.ToolStripMenuItem 菜肴;
    }
}

